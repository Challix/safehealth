import iris
import json

from flask import Flask, redirect, url_for, render_template, request

app = Flask(__name__)


@app.route("/predict")
def home():

    args = request.args
    name = args.get("name")

    return query(name)


def query(name):

    host = "k8s-2a5a5ab1-a92bd7dc-408e126da8-936ab0891aafe954.elb.us-east-2.amazonaws.com"
    port = 1972
    namespace = "USER"
    username = "SQLAdmin"
    password = "SafeHealth_4"

    connection = iris.connect(host, port, namespace, username, password)
    cursor = connection.cursor()

    try:
        sql = '''SELECT 
      TOP(4)
      PREDICT(xxxmodel)*1 as prediction, 
      Level1,
      * 
    FROM 
      SQLUser.Patient3'''
        cursor.execute(sql)
        result = cursor.fetchall()
        if name == "Aarham":
            return json.dumps({"prediction": result[0][1]})
        if name == "Mehtab":
            return json.dumps({"prediction": result[1][1]})
        if name == "Adrian":
            return json.dumps({"prediction": result[2][1]})
        if name == "Michael":
            return json.dumps({"prediction": result[3][1]})
        return json.dumps({"prediction": "Error"})
    except Exception as ex:
        return ex
    finally:
        if cursor:
            cursor.close()
    if connection:
        connection.close()

    # when finished, use the line below to close the connection
    # connection.close()


if __name__ == "__main__":
    app.run()
