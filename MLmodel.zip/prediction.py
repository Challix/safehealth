from flask import Flask, redirect, url_for, render_template, request
import random
import json
from MLmodel import val_predict

app = Flask(__name__)


@app.route("/predict")
def home():

    args = request.args
    model_name = args.get("model_name")
    p_name = args.get("patient_name")

    return query(p_name, model_name)


def query(p_name, model_name):
    if model_name == "breastcancer.h5":

        if p_name == 'adrian':
            path = "unhealthy2.jpg"
        if p_name == 'aarham':
            path = "unhealthy.jpg"
    if model_name == "covid19xray.h5":

        if p_name == 'adrian':
            path = "COVID.png"
        if p_name == 'aarham':
            path = "COVID2.png"

    if model_name == "braintumormodel.h5":

        if p_name == 'adrian':
            path = "Brain.jpg"
        if p_name == 'aarham':
            path = "Brain2.jpg"

    output_prediction = val_predict(path, model_name)

    return output_prediction


if __name__ == "__main__":
    app.run()
