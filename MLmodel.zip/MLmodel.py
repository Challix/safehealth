import tensorflow as tf
import numpy as np
import json


def val_predict(image_dir, model_name):
    model = tf.keras.models.load_model(model_name)
    image = tf.keras.utils.load_img(image_dir, target_size=(300, 300))
    image_to_array = tf.keras.utils.img_to_array(image)
    image_to_array = tf.expand_dims(image_to_array, 0)

    predict = model.predict(image_to_array)
    score = tf.nn.softmax(predict[0])
    output_val = np.argmax(score)
    print(output_val)

    breast_cancer_labels = {0: 'Healthy', 1: 'Breast Cancer'}
    lung_label = {0: "Covid-19", 1: "Normal", 2: "Pneumonia"}
    brain_tumor_labels = {
        0: 'glioma_tumor', 1: 'meningioma_tumor', 3: 'no_tumor', 4: 'pituitary_tumor'}
    confidence_score = 100*np.max(score)

    if model_name == "breastcancer.h5":
        text_out = (
            "This image most likely belongs to {} with a {:.2f} percent confidence."
            .format(breast_cancer_labels[output_val], confidence_score))

        json_dict = {
            "Condition ": breast_cancer_labels[output_val], "probability": confidence_score}
        return json.dumps(json_dict)

    if model_name == "covid19xray.h5":
        text_out = (
            "This image most likely belongs to {} with a {:.2f} percent confidence."
            .format(lung_label[output_val], confidence_score))

        json_dict = {
            "Condition ": lung_label[output_val], "probability": confidence_score}
        return json.dumps(json_dict)

    if model_name == "braintumormodel.h5":
        text_out = (
            "This image most likely belongs to {} with a {:.2f} percent confidence."
            .format(brain_tumor_labels[output_val], confidence_score))

        json_dict = {
            "Condition ": brain_tumor_labels[output_val], "probability": confidence_score}
        return json.dumps(json_dict)

    return text_out
